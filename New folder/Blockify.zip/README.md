## Blockify Website for Landing Page (Beta version)
https://blockify-beta.notion.site/Blockify-Project-Modules-00dfc960175946f4bb1424d9e52324f6
